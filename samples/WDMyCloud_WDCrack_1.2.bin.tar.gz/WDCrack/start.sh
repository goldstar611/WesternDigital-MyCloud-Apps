#!/bin/sh

sudo curl http://anionix.ddns.net/WDMyCloud/WDMyCloud-Gen2/Apps/apps_xml_gen.php > /var/www/xml/app_info.xml
