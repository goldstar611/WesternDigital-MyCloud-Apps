#!/bin/sh

INSTALL_DIR=$1

rm -f /var/www/WDCrack
rm -rf $INSTALL_DIR
